### 请注意::使用先配置IP地址段,否则安装不成功
> chmod +x deploy.sh
./deploy.sh


