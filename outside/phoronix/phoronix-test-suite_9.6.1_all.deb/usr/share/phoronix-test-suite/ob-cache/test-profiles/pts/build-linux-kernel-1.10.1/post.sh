#!/bin/sh
rm -rf linux-5.4.35
