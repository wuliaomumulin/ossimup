#!/bin/sh

cd firefox/
make clean

