#!/bin/sh

rm -rf php-7.4.2
