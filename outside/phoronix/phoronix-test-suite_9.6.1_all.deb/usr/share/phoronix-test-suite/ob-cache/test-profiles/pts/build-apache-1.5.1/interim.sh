#!/bin/sh

cd httpd/
make clean

