#!/bin/sh

cd linux-5.4.35
make clean
