#!/bin/sh

cd linux-5.4-rc3
make clean
