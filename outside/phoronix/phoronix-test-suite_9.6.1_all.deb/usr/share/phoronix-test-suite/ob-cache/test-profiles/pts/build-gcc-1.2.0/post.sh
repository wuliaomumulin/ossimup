#!/bin/sh

rm -rf gcc-9.3.0
