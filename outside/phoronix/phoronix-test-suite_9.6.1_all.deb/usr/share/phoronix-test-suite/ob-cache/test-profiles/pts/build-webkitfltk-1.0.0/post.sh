#!/bin/sh

rm -rf webkitfltk-0.1.1
