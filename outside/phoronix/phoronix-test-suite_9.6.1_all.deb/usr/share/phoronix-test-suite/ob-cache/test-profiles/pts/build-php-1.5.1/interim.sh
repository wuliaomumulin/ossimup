#!/bin/sh

cd php-7.4.2
make clean
