#!/bin/sh

rm -rf MPlayer-1.4/
