#!/bin/sh

cd MPlayer-1.4/
make clean
