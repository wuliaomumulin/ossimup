#!/bin/sh
./httpd_/bin/apachectl -k start -f $HOME/httpd_/conf/httpd.conf
sleep 5
