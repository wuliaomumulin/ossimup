#!/bin/sh
rm -rf linux-5.4-rc3
