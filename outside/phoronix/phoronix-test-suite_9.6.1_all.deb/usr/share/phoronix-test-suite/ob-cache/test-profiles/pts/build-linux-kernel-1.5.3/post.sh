#!/bin/sh

rm -rf linux-3.18-rc6/
