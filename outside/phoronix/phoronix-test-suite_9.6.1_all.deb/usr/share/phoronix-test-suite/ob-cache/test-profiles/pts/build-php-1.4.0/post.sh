#!/bin/sh

rm -rf php-7.1.9/
